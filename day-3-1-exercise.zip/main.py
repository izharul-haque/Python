# 🚨 Don't change the code below 👇
#number = int(input("Which number do you want to check? "))
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

#result = number % 2 == 0
#if result == 1:
 ## print("This is an odd number.")
#else:
 # Print("This is an even number.")

#message = "Alhamdullilah"
#print(message)

### 2nd Attenmpt ###

number= int(input("which number would you like to check?"))
result = number % 2
#modulo = number % 2 == 1
# if number % 2 == 0:
#print("this is an even number")
if result == 1:
  print("This is Odd number and  modulo.")
else:
  print("This is Even Number.")

message = "Alhamdullilah"
print(message)